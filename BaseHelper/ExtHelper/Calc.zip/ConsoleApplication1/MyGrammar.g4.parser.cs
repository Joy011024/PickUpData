﻿namespace ConsoleApplication1
{
    partial class MyGrammarParser
    {
    }
}
