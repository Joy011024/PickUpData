﻿namespace ConsoleApplication1
{
    partial class MyGrammarLexer
    {
    }
}
